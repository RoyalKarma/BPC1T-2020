#pragma once

int alpha(char str[]);
int numb(char str[]);
int numb_of_word(char str[]);
int sentence(char str[]);