#include <iostream>
#include "funkce.h"

int alpha(char str[])
{
	int count = 0;
	int l = strlen(str);
	for (int i = 0; i < l; i++)
	{
		if (isalpha(str[i]))
		{
			count++;
		}

	}
	return count;
}

int numb(char str[])
{
	int count = 0;
	int l = strlen(str);
	for (int i = 0; i < l; i++)
	{
		if (isdigit(str[i]))
		{
			count++;
		}

	}
	return count;
}

int numb_of_word(char str[])
{
	int count = 0;
	int l = strlen(str);
	for (int i = 0; i < l; i++)
	{
		if (isalpha(str[i]))
		{

			if (i == (l - 1))
			{
				count++;
			}
		}
		else if (isspace(str[i]) && isalpha(str[i - 1]))
		{
			count++;
		}
		else if (ispunct(str[i]) && isalpha(str[i - 1]))
		{
			count++;
		}

		else
		{
			count = 0;
		}

	}
	
	return count;
}
int sentence(char str[])
{
	int count = 0;
	int l = strlen(str);
	for (int i = 0; i < l; i++)
	{
		if ((str[i]) == 46)
		{
			count++;
		}
	}
	return count;
}